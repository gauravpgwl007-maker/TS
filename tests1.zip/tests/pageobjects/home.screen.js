class HomeScreen {

    // ==== Core Home Elements ====
    get clockInBtn()       { return $('id=com.gwl.trashscan:id/buttonClockIn'); }
    get clockOutBtn()      { return $('id=com.gwl.trashscan:id/buttonClockOut'); }
    get hamburgerMenu()    { return $('id=com.gwl.trashscan:id/title_bar_left_menu'); }
    get homeIcon()         { return $('id=com.gwl.trashscan:id/title_bar_left_menu'); }

    get workProgressTile() { return $('id=com.gwl.trashscan:id/ll_work_progress'); }
    get pickupTile()       { return $('id=com.gwl.trashscan:id/ivPickUp'); }
    get activityLogsTile() { return $('id=com.gwl.trashscan:id/ivRollback'); }
    get addNotesTile()     { return $('id=com.gwl.trashscan:id/ivAddNotes'); }
    get dailyWorkPlanTile(){ return $('id=com.gwl.trashscan:id/ivAddSubs'); }
    get violationTile()    { return $('id=com.gwl.trashscan:id/ivViolation'); }

    // ==== Wait for Home Screen (toolbar is always present after login) ====
    async waitForHomeScreen() {
        console.log('🏠 Waiting for Home screen...');

        // The hamburger menu / toolbar is always present right after login,
        // regardless of clock-in state. Tiles only appear after clock-in.
        await this.hamburgerMenu.waitForDisplayed({ timeout: 30000 });

        // Also accept the clock-in button as a valid home screen indicator
        const clockInVisible = await this.clockInBtn.isDisplayed().catch(() => false);
        const tilesVisible   = await this.workProgressTile.isDisplayed().catch(() => false);

        if (!clockInVisible && !tilesVisible) {
            console.log('⚠️ Neither clock-in button nor work-progress tile found — check app state');
        }

        console.log('✅ Home screen loaded');
    }

    // ==== Wait specifically for the post-clock-in tile grid ====
    async waitForHomeTiles() {
        console.log('🏠 Waiting for Home screen tiles...');

        await driver.waitUntil(async () => {
            const tiles = [
                this.workProgressTile,
                this.pickupTile,
                this.activityLogsTile,
                this.addNotesTile,
                this.dailyWorkPlanTile,
                this.violationTile
            ];

            let visibleCount = 0;
            for (const tile of tiles) {
                if (await tile.isDisplayed().catch(() => false)) {
                    visibleCount++;
                }
            }
            return visibleCount >= 4;
        }, {
            timeout: 30000,
            timeoutMsg: '❌ Home screen tiles did not load properly'
        });

        console.log('✅ Home screen tiles loaded');
    }

    async backToHome() {
        for (let i = 0; i < 5; i++) {
            const onHome = await this.hamburgerMenu.isDisplayed().catch(() => false);
            if (onHome) break;
            await driver.back();
            await driver.pause(800);
        }
        await this.waitForHomeScreen();
    }

    async allowCameraPermissionIfPresent() {
        try {
            const allowBtn = await $('android=new UiSelector().resourceId("com.android.permissioncontroller:id/permission_allow_button")');
            await allowBtn.waitForDisplayed({ timeout: 3000 });
            await allowBtn.click();
            console.log('📷 Camera permission allowed');
        } catch {
            console.log('ℹ️ Camera permission popup not shown');
        }
    }

}

module.exports = new HomeScreen();