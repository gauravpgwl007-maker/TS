class WorkProgressScreen {

    // ==== Tile on Home Screen ====
    get workProgressTile() { return $('id=com.gwl.trashscan:id/ll_work_progress'); }

    // ==== Porter Work Progress (source-verified: activity_work_progress_non_admin.xml) ====
    get recyclerView()      { return $('id=com.gwl.trashscan:id/recyclerView'); }
    get noRecordView()      { return $('id=com.gwl.trashscan:id/tv_noRecordView'); }

    // ==== Property List Items (source-verified: adapter_item_property_assigned.xml) ====
    get firstPropertyItem() {
        return $('android=new UiSelector().resourceId("com.gwl.trashscan:id/parent_cv_assigned_list").instance(0)');
    }
    get firstPropertyName() {
        return $('android=new UiSelector().resourceId("com.gwl.trashscan:id/assignedproperty_name").instance(0)');
    }
    get firstPropertyAddress() {
        return $('android=new UiSelector().resourceId("com.gwl.trashscan:id/assignedproperty_address").instance(0)');
    }

    // ==== Screen Identifiers ====
    get screenTitle()      { return $('android=new UiSelector().textContains("Assigned Property")'); }
    get screenIdentifier() { return $('android=new UiSelector().textContains("Property")'); }

    // ================================================================
    // ==== Open Work Progress ====
    // ================================================================
    async openWorkProgress() {
        await this.workProgressTile.waitForDisplayed({ timeout: 15000 });
        await this.workProgressTile.click();
        await this.waitForWorkProgressScreen();
    }

    // ================================================================
    // ==== Wait for Screen ====
    // ================================================================
    async waitForWorkProgressScreen() {
        await driver.waitUntil(
            async () => {
                if (await this.recyclerView.isDisplayed().catch(() => false))       return true;
                if (await this.noRecordView.isDisplayed().catch(() => false))       return true;
                if (await this.firstPropertyItem.isDisplayed().catch(() => false))  return true;
                if (await this.screenTitle.isDisplayed().catch(() => false))        return true;
                // Admin service report fallback
                if (await $('id=com.gwl.trashscan:id/recyclerviewList').isDisplayed().catch(() => false)) return true;
                if (await $('id=com.gwl.trashscan:id/textViewNoData').isDisplayed().catch(() => false))   return true;
                return false;
            },
            { timeout: 20000, timeoutMsg: '❌ Work Progress screen did not load' }
        );
        console.log('✅ Work Progress screen loaded');
    }

    // ================================================================
    // ==== State Checks ====
    // ================================================================
    async hasProperties() {
        return await this.firstPropertyItem.isDisplayed().catch(() => false)
            || await this.recyclerView.isDisplayed().catch(() => false);
    }

    async isEmptyState() {
        return await this.noRecordView.isDisplayed().catch(() => false)
            || await $('id=com.gwl.trashscan:id/textViewNoData').isDisplayed().catch(() => false);
    }

    // ================================================================
    // ==== Open First Property ====
    // ================================================================
    async openFirstProperty() {
        try {
            await this.firstPropertyItem.waitForDisplayed({ timeout: 10000 });
            await this.firstPropertyItem.click();
            console.log('📋 First property opened');
            await driver.pause(1500);
        } catch {
            console.log('⚠️ No property item available to tap');
        }
    }
}

module.exports = new WorkProgressScreen();
